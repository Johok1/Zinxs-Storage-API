/*
 
<select name="selectFontFamily">
    <option> Serif </option>
    <option> Arial </option>
    <option> Sans-Serif </option>                                  
    <option> Tahoma </option>
    <option> Verdana </option>
    <option> Lucida Sans Unicode </option>                               
</select>
*/
export default class FontSelector {
    constructor() {
        this.master = document.createElement("select");
        this.master.name = "selectFontFamily";

        // Option 1
        let option1 = document.createElement("option");
        option1.innerHTML = "Serif";
        this.master.appendChild(option1);

        // Option 2
        let option2 = document.createElement("option");
        option2.innerHTML = "Arial";
        this.master.appendChild(option2);

        // Option 3
        let option3 = document.createElement("option");
        option3.innerHTML = "Sans-Serif";
        this.master.appendChild(option3);

        // Option 4
        let option4 = document.createElement("option");
        option4.innerHTML = "Tahoma";
        this.master.appendChild(option4);

        // Option 5
        let option5 = document.createElement("option");
        option5.innerHTML = "Verdana";
        this.master.appendChild(option5);

        // Option 6
        let option6 = document.createElement("option");
        option6.innerHTML = "Lucida Sans Unicode";
        this.master.appendChild(option6);
    }

    setFontFamily = (fontFamily) => {
        if (fontFamily != undefined) {
            for (let x = 0; x < this.master.options.length; x++) {
                console.log(this.master.options[x].value.toLowerCase() + " options")
                console.log(fontFamily.toLowerCase())
                console.log(this.master.options[x].value.toLowerCase() == fontFamily.toLowerCase())
                if (this.master.options[x].value.toLowerCase() == fontFamily.toLowerCase()) {
                    this.master.selectedIndex = x
                }
            }
        }
    }

    getSelectedFontFamily = () => {
        return this.master.options[this.master.selectedIndex].value
    }
}
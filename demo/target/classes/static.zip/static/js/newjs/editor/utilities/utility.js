export default class Utility{

   
}
/*
 
<div class="dropdown">
  <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
    Hyperlink Tool
  </button>
  <ul class="dropdown-menu">
    <li>Hyperlink</li>
    <li><input type="text" placeholder="Enter a URL"></li>
    <li><button>Submit</button></li>
  </ul>
</div>
*/
export default class HyperlinkTool {
    constructor() {
        this.master = document.createElement("div");
        this.master.className = "dropdown";

        this.button1 = document.createElement("button");
        this.button1.className = "btn btn-secondary dropdown-toggle";
        this.button1.type = "button";
        this.button1.setAttribute("data-bs-toggle", "dropdown");
        this.button1.setAttribute("aria-expanded", "false");
        this.button1.innerHTML = "Hyperlink Tool";
       

        this.ul = document.createElement("ul");
       // this.ul.className = "dropdown-menu";


        const inputLi = document.createElement("li");
        const input = document.createElement("input");
        
        this.inputPoint = input
        input.type = "text";
        input.placeholder = "Enter a URL";
        inputLi.appendChild(input);
        this.ul.appendChild(inputLi);

        const buttonLi = document.createElement("li");
        const button = document.createElement("button");
        button.innerHTML = "Submit";
        buttonLi.appendChild(button);
        this.ul.appendChild(buttonLi);
        this.buttonPoint = button
       // this.master.appendChild(this.button1);
        this.master.appendChild(this.ul);
    }

   

    getInput = () => {
        return this.inputPoint.value
    }

    attachSubmitButtonListener = (handler) => {
        this.buttonPoint.addEventListener("click", handler)
    }

}


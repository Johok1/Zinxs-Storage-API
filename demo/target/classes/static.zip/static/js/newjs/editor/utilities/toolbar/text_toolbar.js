
import ColorPicker from './components/color_picker.js'
import FontSelector from './components/font_selector.js'
import HyperlinkTool from './components/hyperlink_tool.js'

export default class TextToolbar{

    constructor(element) {
        this.toolbarDiv = document.getElementById("toolbarDiv")
        this.registerElement(element)
       // this.constructToolbar()
        this.page = document.getElementById("page")
        this.header = false 
        this.bold = false
    }

   

    registerElement = (element) => {
        if (element.classList.contains("text")) {
            this.element = element
        } else {
            console.error("element type not suitable for toolbar")
        }
    }
    constructToolbar = () => {
       // this.colorPicker = new ColorPicker()
     //   this.toolbarDiv.appendChild(this.colorPicker.master)
      //  this.colorPicker.setValue(this.element.style.color)

        this.colorBtn = document.createElement("button")
        this.colorBtn.innerText = "Apply Color"
       
      //  this.toolbarDiv.appendChild(this.colorBtn)

        this.fontSelector = new FontSelector()
       // this.fontSelector.setFontFamily(this.element.style.fontFamily)
      //  this.toolbarDiv.appendChild(this.fontSelector.master)

        

       // let headerBtn = document.createElement("button")
      //  headerBtn.innerText = "Header Button"

      //  headerBtn.addEventListener("click", this.handleHeaderButton)

        this.boldBtn = document.createElement("button")
        this.boldBtn.innerText = "Bold"

       

        this.underlineBtn = document.createElement("button")
        this.underlineBtn.innerText = "Underline"

        

       // this.highlightBtn = document.createElement("button")
       // this.highlightBtn.innerText = "Highlight"

        this.removeStyleBtn = document.createElement("button")
        this.removeStyleBtn.innerText = "Remove Style"

       

        this.fontSlider = document.createElement("input")
        this.fontSlider.type = "range"
        this.fontSlider.classList.add("form-range")
        this.fontSlider.min = 5
        this.fontSlider.max = 100
        this.fontSlider.step = 0.5
        let int = parseInt(this.element.style.fontSize)
        console.log(this.element.style.fontSize)
        this.fontSliderLabel = document.createElement("label")
        
   

        this.hyperlinkTool = new HyperlinkTool()
   

        this.dragButton = document.createElement("button")
        this.dragButton.innerText = "Enable Drag"
        this.dragButton.addEventListener("click", this.enableDragMode)

        this.disableDragButton = document.createElement("button")
        this.disableDragButton.innerText = "Disable Drag"
        this.disableDragButton.addEventListener("click", this.disableDragMode)

        this.resizeButton = document.createElement("button")
        this.resizeButton.innerText = "Enable Resize"

        this.disableResizeButton = document.createElement("button")
        this.disableResizeButton.innerText = "Disable Resize"

        this.editTextBtn = document.createElement("button")
        this.editTextBtn.innerText = "Edit Text"

        this.disabelEditText = document.createElement("button")
        this.disabelEditText.innerText = "Disable Edit Text"

        this.toolbarDiv.appendChild(this.editTextBtn)
        this.toolbarDiv.appendChild(this.disabelEditText)
        this.toolbarDiv.appendChild(this.dragButton)
        this.toolbarDiv.appendChild(this.disableDragButton)
        this.toolbarDiv.appendChild(this.resizeButton)
        this.toolbarDiv.appendChild(this.disableResizeButton)
        //this.toolbarDiv.appendChild(this.highlightBtn)
        //this.toolbarDiv.appendChild(headerBtn)
      //  this.toolbarDiv.appendChild(this.boldBtn)
      //  this.toolbarDiv.appendChild(this.underlineBtn)
      //  this.toolbarDiv.appendChild(this.removeStyleBtn)
      //  this.toolbarDiv.appendChild(this.fontSlider)
      //  this.toolbarDiv.appendChild(this.fontSliderLabel)
      //  this.toolbarDiv.appendChild(this.hyperlinkTool.master)
     
        
    }

    setFontFamily = (fontFamily) => {
        this.fontSelector.setFontFamily(fontFamily)
    }

    setFontSlider = (value) => {
        this.fontSlider.value = parseFloat(value)
        this.fontSliderLabel.innerText = value
    }
   
    
    handleFontSliderChange = () => {
        this.element.style.fontSize = this.fontSlider.value + "px"
        this.fontSliderLabel.innerText = this.element.style.fontSize 
    }



    handleUnderlineButton = () => {
        if (this.element.style.textDecoration == "underline") {
            this.element.style.textDecoration = "none"
        } else {
            this.element.style.textDecoration = "underline"
        }
    }

    handleHeaderButton = () => {

        if (this.header) {
            this.element.style.fontSize = "15px"
            this.header = false 
        } else {
            this.element.style.fontSize = "30px"
            this.header = true 
        }
        
    }

    handleBoldButton = () => {
        if (this.bold) {
            this.element.style.fontWeight = "normal"
            this.bold = false
        } else {
            this.element.style.fontWeight = "bold"
            this.bold = true
        }

    }

    handleFontSelectorChange = () => {
        this.element.style.fontFamily = this.fontSelector.getSelectedFontFamily()
    }

    handleColorBtnClick = () => {
        this.element.style.color = this.colorPicker.getValue()
    }

    enableDragMode = () => {
        this.element.contentEditable = false
        this.element.style.userSelect = "none"
        this.dragElement(this.element)
    }

    disableDragMode = () => {
        this.disableDragElement(this.element)
        //this.element.contentEditable = true
        this.element.style.userSelect = "default"
    }


    disableDragElement = (elmnt) => {

        elmnt.onmousedown = undefined
    }

    dragElement = (elmnt) => {


        elmnt.onmousedown = this.dragElementDown
        elmnt.onmouseleave = this.stopDrag
        elmnt.onmouseup = this.stopDrag

    }

    stopDrag = (event) => {
        event.currentTarget.removeEventListener("mousemove", this.onMouseDrag)
    }

    dragElementDown = (event) => {

        event.currentTarget.addEventListener("mousemove", this.onMouseDrag)
    }
   onMouseDrag({ movementX, movementY }) {
    let container = document.getElementById("page");
    let containerRect = container.getBoundingClientRect();

    let elementStyles = window.getComputedStyle(this);
    let elementLeft = parseFloat(elementStyles.left) || 0; // Use 0 if left is not defined
       let elementTop = parseFloat(elementStyles.top) || 0; // Use 0 if top is not defined
       let elementRect = this.getBoundingClientRect()

    let newLeft = elementLeft + movementX;
    let newTop = elementTop + movementY;

    // Calculate the boundaries based on the container's position and dimensions
    let minLeft = containerRect.left - elementRect.left; // Adjusted for container's position
    let maxLeft = containerRect.right - containerRect.left - elementRect.width; // Adjusted for container's position
    let minTop = containerRect.top - elementRect.top; // Adjusted for container's position
    let maxTop = containerRect.bottom - containerRect.top - elementRect.height; // Adjusted for container's position

    // Ensure the element stays within the boundaries
    newLeft = Math.max(minLeft, Math.min(newLeft, maxLeft));
    newTop = Math.max(minTop, Math.min(newTop, maxTop));

    // Update the element's position
    this.style.left = `${newLeft}px`;
    this.style.top = `${newTop}px`;
}







}
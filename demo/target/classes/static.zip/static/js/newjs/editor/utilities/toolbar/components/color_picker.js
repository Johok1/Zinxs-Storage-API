import './jscolor.js'

/*
 * Color: <button data-jscolor="{valueElement:'#val4', alphaElement:'#alp4'}"></button>
					Value: <input id="val4" value="#3399FF80">
					Alpha: <input id="alp4">
 */ 
export default class ColorPicker {
    constructor() {
        this.master = document.createElement("div");

        // Button
        this.button = document.createElement("button");
        this.button.setAttribute("data-jscolor", "{valueElement:'#val4', alphaElement:'#alp4'}");
        this.picker = new JSColor(this.button)
       

        // Value Input
        this.valueInput = document.createElement("input");
        this.valueInput.id = "val4";
        this.picker.valueElement = this.valueInput

        // Alpha Input
        this.alphaInput = document.createElement("input");
        this.alphaInput.id = "alp4";

        // Appending elements to the master div
        this.master.appendChild(document.createTextNode("Color: "));
        this.master.appendChild(this.button);
        this.master.appendChild(document.createTextNode("Value: "));
        this.master.appendChild(this.valueInput);
       // this.master.appendChild(document.createTextNode("Alpha: "));
       // this.master.appendChild(this.alphaInput);
        
        this.picker.show()
    }

    getValue = () => {
        return this.valueInput.value
    }

    setValue = (value) => {
        this.valueInput.value = value
        this.picker.fromString(value) 
    }
}

import ImageToolbar from './toolbar/image_toolbar.js'

export default class ImageUtility {
    constructor(element) {
        this.toolbar = new ImageToolbar(element)
        this.element = element

    }
    constructToolbar = () => {
        this.toolbar.constructToolbar()
        this.attachFileInputHandler(this.handleFileInput)
        this.attachFileInputSubmitHandler()
    }


    attachFileInputSubmitHandler = () => {
        this.toolbar.fileInputSubmit.addEventListener("click", this.handleFileInputSubmit)
    }

    handleFileInputSubmit = () => {
        this.element.src = URL.createObjectURL(this.toolbar.fileInput.files.item(0))
    }

    attachFileInputHandler = (handler) => {
        this.toolbar.fileInput.addEventListener("change", handler)
    }

    handleFileInput = () => {
        let file = URL.createObjectURL(this.toolbar.fileInput.files.item(0))
        this.toolbar.img.src = file
    }

    deselectAll = () => {
        this.toolbar.deselectAll()
    }

    selectElement = () => {

    }

    deselectElement = () => {

    }

}
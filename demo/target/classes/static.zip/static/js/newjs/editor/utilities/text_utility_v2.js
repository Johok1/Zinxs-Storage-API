
import TextToolbar from './toolbar/text_toolbar.js'

import './summernote.js'

export default class TextUtility {
    constructor(element) {
        this.toolbar = new TextToolbar(element)
        this.element = element
 
    }

    selectElement = () => {
        this.element.style.border = "solid 1px red"

      
       
       
    }

    deselectElement = () => {
        this.element.style.border = ""
      

    }

    


    
    constructToolbar = () => {
        this.toolbar.constructToolbar()
      //  this.initFontSlider()
      //  this.initHighlightBtn()
      //  this.initRemoveStyleBtn()
      //  this.initBoldBtn()
      //  this.initColorBtn()
      //  this.initUnderlineBtn()
      //  this.initHyperlinkBtn()
      //  this.initFontSelectorChange()
        this.initBoxResizeBtn()
        this.initBoxDisableResizeBtn()
        this.initEditTextBtn()
        this.initDisableEditTextBtn()
    }

    initFontSlider = () => {
        if (document.getSelection().focusNode != null) {
            let fontSize = document.getSelection().focusNode.parentElement.style.fontSize
            if (this.checkUndefinedNullEmpty(fontSize)) {
                this.setElementFontSize()
            } else {
                this.toolbar.fontSlider.value = fontSize
                this.toolbar.fontSliderLabel.innerText = fontSize
            }
        } else {
            this.setElementFontSize()
        }
        this.toolbar.fontSlider.addEventListener("change", this.handleFontSliderChange)
       }

    setElementFontSize = () => {
        let fontSize = this.element.style.fontSize
        if (this.checkUndefinedNullEmpty(fontSize)) {
            this.toolbar.fontSlider.value = 15
            this.toolbar.fontSliderLabel.innerText = "15px"
        } else {
            this.toolbar.fontSlider.value = fontSize
            this.toolbar.fontSliderLabel.innerText = fontSize + "px"
        }
    }

    initFontSelectorChange = () => {
        this.toolbar.fontSelector.master.onchange = this.handleFontSelectorChange
    }

    initHighlightBtn = () => {
        this.toolbar.highlightBtn.addEventListener("click", this.handleHighlightButton)
    }

    initRemoveStyleBtn = () => {
        this.toolbar.removeStyleBtn.addEventListener("click", this.handleRemoveStyleButton)
    }

    initBoldBtn = () => {
        this.toolbar.boldBtn.addEventListener("click", this.handleBoldButton)
    }

    initColorBtn = () => {
        this.toolbar.colorBtn.addEventListener("click", this.handleColorBtnClick)
    }

    initUnderlineBtn = () => {
        this.toolbar.underlineBtn.addEventListener("click", this.handleUnderlineButton)
    }

    initHyperlinkBtn = () => {
        this.toolbar.hyperlinkTool.attachSubmitButtonListener(this.handleHyperlinkSubmit)
    }

    initBoxResizeBtn = () => {
        this.toolbar.resizeButton.addEventListener("click", this.boxResize)
    }

    initBoxDisableResizeBtn = () => {
        this.toolbar.disableResizeButton.addEventListener("click", this.boxDisableResize)
    }

    checkUndefinedNullEmpty = (check) => {
        if (check == undefined || check == null || check == "") {
            return true
        } else {
            return false 
        }
    }       

    initEditTextBtn = () => {
        this.toolbar.editTextBtn.addEventListener("click", this.handleEditText)
    }

    initDisableEditTextBtn = () => {
        this.toolbar.disabelEditText.addEventListener("click", this.handleDisableEditText)
    }


    handleEditText = () => {
        console.log(this.element)
        console.log(this.element.firstChild)
        this.element.classList.add("summernote")
        let top = this.element.style.top
        let left = this.element.style.left
        let width = this.element.style.width
        let height = this.element.style.height
        $(document).ready(function () {
            $('.summernote').summernote({
                focus: true, airMode: true, popover: {
                    air: [
                        ['style', ['style']],
                        ['font', ['bold', 'underline', 'clear']],
                        ['color', ['color']],
                        ['para', ['ul', 'ol', 'paragraph']],
                        ['insert', ['link']]
                    ]
                },
                fontColor: '#000000'
            });
            $('.note-editor').css({
                color: "black",
                position: "absolute",
                top: top,
                left: left,
                width: width,
                height: height
            })
        });
    }

    handleDisableEditText = () => {
        var markup = $('.summernote').summernote('code');

      //  this.element.innerHTML = markup

        $('.summernote').summernote('destroy');

        this.element.firstChild.classList.remove("summernote")
    }

    handleFontSliderChange = () => {
        if (!this.checkUndefinedNullEmpty(document.getSelection())) {

            this.applyStyle(this.element, "label", { fontSize: this.toolbar.fontSlider.value + "px" })
            this.toolbar.fontSliderLabel.innerText = this.toolbar.fontSlider.value + "px"
           
        }
    }
    
    handleHighlightButton = () => {
        if (!this.checkUndefinedNullEmpty(document.getSelection())) {
            let mark = document.createElement("mark")
            mark.innerText = document.getSelection()
            mark.style = this.element.style
            this.replaceSelectWith(mark.outerHTML)
            this.clearSelection()
        } 
    }
    handleRemoveStyleButton = () => {


        this.applyNullStyle()

        /*
        let par = this.element
        let selectedText = window.getSelection().toString();

        if (selectedText) {
            let range = window.getSelection().getRangeAt(0);
            let strippedText = selectedText.replace(/<(\/?)(b|u|font).*?>/g, ''); // Remove <b>, </b>, <u>, </u>, <font>, </font> tags and their contents

            // Insert the stripped text back into the range
            range.deleteContents();
            range.insertNode(document.createTextNode(strippedText));
        }
        */
    }

    removeStyleFromHTML = (fragment) => {
        // Convert the fragment to a string
        let htmlString = new XMLSerializer().serializeToString(fragment);

        // Remove unwanted style-related tags
        let strippedHTML = htmlString.replace(/<(\/?)(b|u|font|a|label).*?>/gi, '');

        return strippedHTML;
    }


    handleBoldButton = () => {
        if (!this.checkUndefinedNullEmpty(document.getSelection())) {

            this.applyStyle(this.element, 'b');
        }
     
    }

    handleColorBtnClick = () => {
        if (!this.checkUndefinedNullEmpty(document.getSelection())) {

            this.applyStyle(this.element, 'font', { color: this.toolbar.colorPicker.getValue() });
            
        }
    }

    handleUnderlineButton = () => {
        if (!this.checkUndefinedNullEmpty(document.getSelection())) {
            this.applyStyle(this.element, 'u');
        }
    }

    handleHyperlinkSubmit = () => {
        if (!this.checkUndefinedNullEmpty(document.getSelection())) {
            this.applyLink(this.element, this.toolbar.hyperlinkTool.getInput() )
        }
    }

    handleFontSelectorChange = () => {
        if (!this.checkUndefinedNullEmpty(document.getSelection())) {

            this.applyStyle(this.element, "span", { fontFamily: this.toolbar.fontSelector.getSelectedFontFamily() })
        }
        
    }

    applyLink = (par, url) => {
        const selectedText = window.getSelection().toString();
        if (selectedText) {
            const range = window.getSelection().getRangeAt(0);
            const link = document.createElement('a');
            link.draggable = false
            link.href = url;
            link.textContent = selectedText;

            // Wrap the selected text with the link
            range.deleteContents();
            range.insertNode(link);
        }
    }

    applyNullStyle = () => {
        const selectedText = window.getSelection().toString();
        if (selectedText) {
            const range = window.getSelection().getRangeAt(0);
            let tag = "label"
            const wrapper = document.createElement(tag);
           // Object.assign(wrapper.style, style);

            wrapper.classList.add("style")

          


            // Clone the selected range

            console.log(range)
            // Surround the cloned range with the new tag
            const fragment = range.extractContents();
            wrapper.innerText = selectedText
            console.log(fragment)
            //wrapper.appendChild(fragment);

            range.insertNode(wrapper);
            //this.removeStyleClasses(wrapper)
            // Restore the selection
            window.getSelection().removeAllRanges();
            window.getSelection().addRange(range);
        }
    }

    applyStyle=(par, tag, style = {})=> {
        const selectedText = window.getSelection().toString();
        if (selectedText) {
            const range = window.getSelection().getRangeAt(0);
            const wrapper = document.createElement(tag);
            Object.assign(wrapper.style, style);
            
            wrapper.classList.add("style")

            if (tag.toLowerCase() === "label" && style.hasOwnProperty("fontSize")) {
                this.attachCompClickHandler(wrapper, tag.toLowerCase())
            } else if (tag.toLowerCase() === "span" && style.hasOwnProperty("fontFamily")) {
                this.attachCompFontClickHandler(wrapper, tag.toLowerCase())
            } else {
                console.error("invalid style application " + tag + " " + style)
            }

          

            // Clone the selected range
       
            console.log(range)
            // Surround the cloned range with the new tag
            const fragment = range.extractContents();
           
            console.log(fragment)
            wrapper.appendChild(fragment);

            range.insertNode(wrapper);
            //this.removeStyleClasses(wrapper)
            // Restore the selection
            window.getSelection().removeAllRanges();
            window.getSelection().addRange(range);
        }
    }

    removeStyleClasses = (parentElement) => {
        // Helper function to remove style classes recursively
        const removeStyleClassesRecursively = (element) => {
            // Get the tag name of the parent element
            const parentTagName = element.tagName.toLowerCase();

            // Get all elements with the class name "style" that are children of the current element
            const styleElements = element.querySelectorAll('.style');

            // Iterate over each found style element
            styleElements.forEach(styleElement => {
                // Check if the style element matches the tag name of the parent element
                if (styleElement.tagName.toLowerCase() === parentTagName) {
                    // Get the text content of the style element
                    const textContent = styleElement.textContent;

                    // Create a new text node containing the text content
                    const textNode = document.createTextNode(textContent);

                    // Replace the style element with the new text node
                    styleElement.parentNode.replaceChild(textNode, styleElement);
                }
            });

            // Recursively remove style classes from all child elements
            element.childNodes.forEach(child => {
                if (child.nodeType === 1) { // If it's an element node
                    removeStyleClassesRecursively(child);
                }
            });
        };

        // Start removing style classes recursively from the parent element
        removeStyleClassesRecursively(parentElement);
    };

    attachCompFontClickHandler = (el, tag) => {
        let handler = this.compClickFontHandler
        el.addEventListener("click", function (event) {

            handler(el, tag)
           // event.stopPropagation()
        })
    }

    compClickFontHandler = (el, tag) => {


        if (el.tagName.toLowerCase() != tag) {
            let parent = this.findParentWithTag(el, tag)
            if (parent != null) {
                this.toolbar.setFontFamily(parent.style.fontFamily)
                console.log("parent fire " + parent.style.fontFamily + " " + parent.tagName)
            } else {
                console.error("parent is null! " + parent)
            }
        } else {
            this.toolbar.setFontFamily(el.style.fontFamily)
            console.log("fire " + el.style.fontFamily + " " + el.tagName)
        }
    }


    attachCompClickHandler = (el,tag) => {
        let handler = this.compClickHandler
        el.addEventListener("click", function (event) {
            
            handler(el,tag)
            event.stopPropagation()
        })
    }

    compClickHandler = (el,tag) => {
       
        
        if (el.tagName.toLowerCase() != tag) {
            let parent = this.findParentWithTag(el, tag)
            if (parent != null) {
                this.toolbar.setFontSlider(parent.style.fontSize)
                console.log("parent fire " + parent.style.fontSize + " " + parent.tagName)
            } else {
                console.error("parent is null! " + parent)
            }
        } else {
            this.toolbar.setFontSlider(el.style.fontSize)
            console.log("fire " + el.style.fontSize + " " + el.tagName)
        }
    }

    findParentWithTag = (element, tagName) => {
        let parent = element.parentElement;
        while (parent) {
            if (parent.tagName.toLowerCase() === tagName.toLowerCase()) {
                return parent;
            }
            parent = parent.parentElement;
        }
        return null; // If no parent with the specified tag name is found
    }

    removeStyle = () => {
        const selectedText = window.getSelection().toString();
        if (selectedText) {
            const range = window.getSelection().getRangeAt(0);
            let tag = "label"

            const wrapper = document.createElement(tag);
            wrapper.innerText = window.getSelection()
           
            // Clone the selected range
            const clonedRange = range.cloneRange();

            // Surround the cloned range with the new tag
            const fragment = clonedRange.extractContents();
           // wrapper.appendChild(fragment);
            
            clonedRange.insertNode(wrapper);

            // Restore the selection
            window.getSelection().removeAllRanges();
            window.getSelection().addRange(clonedRange);
        }
    }

    removeSpecifiedElements = (wrapper) => {
        for (let i = 0; i < wrapper.childNodes.length; i++) {
            const node = wrapper.childNodes[i];

            // Check if the node is one of the specified types
            if (node.nodeType === Node.ELEMENT_NODE) {
                const tagName = node.tagName.toLowerCase();
                if (tagName === 'b' || tagName === 'u' || tagName === 'label' || tagName === 'font') {
                    // Extract text content and move it outside
                    const text = node.textContent;
                    const textNode = document.createTextNode(text);
                    wrapper.insertBefore(textNode, node);
                    wrapper.removeChild(node);
                    i--; // Adjust index after removing node
                } else {
                    // Recursively call the function for child nodes
                    removeSpecifiedElements(node);
                }
            }
        }
    }



    boxResize = () => {
        this.resizeBoxElement(this.element)
    }

    boxDisableResize = () => {
        this.element.onmousedown = undefined
    }

    resizeBoxElement = (elmnt) => {



        // otherwise, move the DIV from anywhere inside the DIV:
        elmnt.onmousedown = this.dragBoxElement
        elmnt.onmouseleave = this.stopBoxDrag
        elmnt.onmouseup = this.stopBoxDrag

    }

    stopBoxDrag = (event) => {
        event.currentTarget.removeEventListener("mousemove", this.onBoxDrag)
    }

    dragBoxElement = (event) => {

        event.currentTarget.addEventListener("mousemove", this.onBoxDrag)
    }

    onBoxDrag({ movementX, movementY }) {
        let container = document.getElementById("page");
        let containerRect = container.getBoundingClientRect();

        let elementStyles = window.getComputedStyle(this);
        let elementWidth = parseFloat(elementStyles.width) || 0; // Use 0 if width is not defined
        let elementHeight = parseFloat(elementStyles.height) || 0; // Use 0 if height is not defined
        let elementRect = this.getBoundingClientRect();

        let newWidth = elementWidth + movementX;
        let newHeight = elementHeight + movementY;

        // Calculate the maximum width and height to avoid overflowing the container
        let maxWidth = containerRect.right - elementRect.left; // Maximum width without overflowing the container horizontally
        let maxHeight = containerRect.bottom - elementRect.top; // Maximum height without overflowing the container vertically

        // Ensure the element stays within the maximum width and height
        newWidth = Math.min(newWidth, maxWidth);
        newHeight = Math.min(newHeight, maxHeight);

        // Update the element's size
        this.style.width = `${newWidth}px`;
        this.style.height = `${newHeight}px`;
    }




        clearSelection = () => {
            if (window.getSelection) { window.getSelection().removeAllRanges(); }
            else if (document.selection) { document.selection.empty(); }
        }
}
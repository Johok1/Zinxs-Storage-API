
import TextToolbar from './toolbar/text_toolbar.js'

export default class TextUtility {
    constructor(element) {
        this.toolbar = new TextToolbar(element)
        this.element = element
 
    }

    
    constructToolbar = () => {
        this.toolbar.constructToolbar()
        this.initFontSlider()
      //  this.initHighlightBtn()
        this.initRemoveStyleBtn()
        this.initBoldBtn()
        this.initColorBtn()
        this.initUnderlineBtn()
        this.initHyperlinkBtn()
        this.initFontSelectorChange()
    }

    initFontSlider = () => {
        if (document.getSelection().focusNode != null) {
            let fontSize = document.getSelection().focusNode.parentElement.style.fontSize
            if (this.checkUndefinedNullEmpty(fontSize)) {
                this.setElementFontSize()
            } else {
                this.toolbar.fontSlider.value = fontSize
                this.toolbar.fontSliderLabel.innerText = fontSize
            }
        } else {
            this.setElementFontSize()
        }
        this.toolbar.fontSlider.addEventListener("change", this.handleFontSliderChange)
       }

    setElementFontSize = () => {
        let fontSize = this.element.style.fontSize
        if (this.checkUndefinedNullEmpty(fontSize)) {
            this.toolbar.fontSlider.value = 15
            this.toolbar.fontSliderLabel.innerText = "15px"
        } else {
            this.toolbar.fontSlider.value = fontSize
            this.toolbar.fontSliderLabel.innerText = fontSize + "px"
        }
    }

    initFontSelectorChange = () => {
        this.toolbar.fontSelector.master.onchange = this.handleFontSelectorChange
    }

    initHighlightBtn = () => {
        this.toolbar.highlightBtn.addEventListener("click", this.handleHighlightButton)
    }

    initRemoveStyleBtn = () => {
        this.toolbar.removeStyleBtn.addEventListener("click", this.handleRemoveStyleButton)
    }

    initBoldBtn = () => {
        this.toolbar.boldBtn.addEventListener("click", this.handleBoldButton)
    }

    initColorBtn = () => {
        this.toolbar.colorBtn.addEventListener("click", this.handleColorBtnClick)
    }

    initUnderlineBtn = () => {
        this.toolbar.underlineBtn.addEventListener("click", this.handleUnderlineButton)
    }

    initHyperlinkBtn = () => {
        this.toolbar.hyperlinkTool.attachSubmitButtonListener(this.handleHyperlinkSubmit)
    }

    checkUndefinedNullEmpty = (check) => {
        if (check == undefined || check == null || check == "") {
            return true
        } else {
            return false 
        }
    }       
       
    

    handleFontSliderChange = () => {
        if (!this.checkUndefinedNullEmpty(document.getSelection())) {
            let label = document.createElement("label")
            label.style.fontWeight = document.getSelection().focusNode.parentElement.style.fontWeight
            label.style.color = document.getSelection().focusNode.parentElement.style.color
            label.style.textDecoration = document.getSelection().focusNode.parentElement.style.textDecoration
            label.style.fontFamily = document.getSelection().focusNode.parentElement.style.fontFamily
            label.innerText = document.getSelection()
            label.classList.add("comp")
            label.style.fontSize = this.toolbar.fontSlider.value + "px"

            this.toolbar.fontSliderLabel.innerText = label.style.fontSize
            this.replaceSelectWith(label.outerHTML)
        }
    }

    handleHighlightButton = () => {
        if (!this.checkUndefinedNullEmpty(document.getSelection())) {
            let mark = document.createElement("mark")
            mark.innerText = document.getSelection()
            mark.style = this.element.style
            this.replaceSelectWith(mark.outerHTML)
            this.clearSelection()
        } 
    }

    handleRemoveStyleButton = () => {
        if (!this.checkUndefinedNullEmpty(document.getSelection())) {
            let label = document.createElement("label")
            label.innerText = document.getSelection()
            label.style.fontSize = document.getSelection().focusNode.parentElement.style.fontSize
            label.classList.add("comp")
            label.style.color = "black"
            label.style.fontWeight = "normal"
            label.style.textDecoration = "none"
            this.replaceSelectWith(label.outerHTML)
            this.clearSelection()
        }
    }

    handleBoldButton = () => {
        if (!this.checkUndefinedNullEmpty(document.getSelection())) {
            let label = document.createElement("label")
            label.style.fontSize = document.getSelection().focusNode.parentElement.style.fontSize
            label.style.color = document.getSelection().focusNode.parentElement.style.color
            label.style.fontFamily = document.getSelection().focusNode.parentElement.style.fontFamily
            label.style.textDecoration = document.getSelection().focusNode.parentElement.style.textDecoration
            label.style.fontWeight = "bold"
            label.classList.add("comp")
            label.innerText = document.getSelection()
            this.replaceSelectWith(label.outerHTML)
            this.clearSelection()
        }
     
    }

    handleColorBtnClick = () => {
        if (!this.checkUndefinedNullEmpty(document.getSelection())) {
            let label = document.createElement("label")
            label.style.fontSize = document.getSelection().focusNode.parentElement.style.fontSize
            label.style.fontWeight = document.getSelection().focusNode.parentElement.style.fontWeight
            label.style.fontFamily = document.getSelection().focusNode.parentElement.style.fontFamily
            label.style.textDecoration = document.getSelection().focusNode.parentElement.style.textDecoration
            label.innerText = document.getSelection()
            label.classList.add("comp")
            label.style.color = this.toolbar.colorPicker.getValue()
            this.replaceSelectWith(label.outerHTML)
            this.clearSelection()
        }
    }

    handleUnderlineButton = () => {
        if (!this.checkUndefinedNullEmpty(document.getSelection())) {
            let label = document.createElement("label")
            label.style.fontSize = document.getSelection().focusNode.parentElement.style.fontSize
            label.style.fontWeight = document.getSelection().focusNode.parentElement.style.fontWeight
            label.style.color = document.getSelection().focusNode.parentElement.style.color
            label.style.fontFamily = document.getSelection().focusNode.parentElement.style.fontFamily
            label.innerText = document.getSelection()
            label.classList.add("comp")
            label.style.textDecoration = "underline"
            this.replaceSelectWith(label.outerHTML)
            this.clearSelection()
        }
    }

    handleHyperlinkSubmit = () => {
        if (!this.checkUndefinedNullEmpty(document.getSelection())) {
            let a = document.createElement("a")
            a.href = this.toolbar.hyperlinkTool.getInput()
            a.classList.add("comp")
            a.style.fontSize = document.getSelection().focusNode.parentElement.style.fontSize
            a.style.fontWeight = document.getSelection().focusNode.parentElement.style.fontWeight
            a.style.color = document.getSelection().focusNode.parentElement.style.color
            a.style.textDecoration = document.getSelection().focusNode.parentElement.style.textDecoration
            a.style.fontFamily = document.getSelection().focusNode.parentElement.style.fontFamily
            a.innerText = document.getSelection()


            
            this.replaceSelectWith(a.outerHTML)
            this.clearSelection()
        }
    }

    handleFontSelectorChange = () => {
        if (!this.checkUndefinedNullEmpty(document.getSelection())) {
            let label = document.createElement("label")
            label.classList.add("comp")
            label.style.fontSize = document.getSelection().focusNode.parentElement.style.fontSize
            label.style.fontWeight = document.getSelection().focusNode.parentElement.style.fontWeight
            label.style.color = document.getSelection().focusNode.parentElement.style.color
            label.innerText = document.getSelection()
            label.style.textDecoration = document.getSelection().focusNode.parentElement.style.textDecoration
            label.style.fontFamily = this.toolbar.fontSelector.getSelectedFontFamily()

            this.replaceSelectWith(label.outerHTML)
            this.clearSelection()
        }
        
    }

    replaceSelectWith = (html) => {
        if (document.getSelection) {

            if (document.getSelection() != "") {
                this.replaceSelection(html, true)
               
            } else {
                this.replaceSelection(html, false)
               
            }

        }
    }

    replaceSelection(html, selectInserted) {
        var sel, range, fragment;
        console.log("hi")
        if (typeof window.getSelection != "undefined") {
            // IE 9 and other non-IE browsers
            sel = window.getSelection();

            // Test that the Selection object contains at least one Range
            if (sel.getRangeAt && sel.rangeCount) {
                // Get the first Range (only Firefox supports more than one)
                range = window.getSelection().getRangeAt(0);
                range.deleteContents();

                // Create a DocumentFragment to insert and populate it with HTML
                // Need to test for the existence of range.createContextualFragment
                // because it's non-standard and IE 9 does not support it
                if (range.createContextualFragment) {
                    fragment = range.createContextualFragment(html);
                } else {
                    // In IE 9 we need to use innerHTML of a temporary element
                    var div = document.createElement("div"), child;
                    div.innerHTML = html;
                    fragment = document.createDocumentFragment();
                    while ((child = div.firstChild)) {
                        fragment.appendChild(child);
                    }
                }
                var firstInsertedNode = fragment.firstChild;
                var lastInsertedNode = fragment.lastChild;
                range.insertNode(fragment);
                if (selectInserted) {
                    if (firstInsertedNode) {
                        range.setStartBefore(firstInsertedNode);
                        range.setEndAfter(lastInsertedNode);
                    }
                    sel.removeAllRanges();
                    sel.addRange(range);
                }
            }
        } else if (document.selection && document.selection.type != "Control") {
            // IE 8 and below
            range = document.selection.createRange();
            range.pasteHTML(html);
        }
    }
    clearSelection() {
        if (window.getSelection) { window.getSelection().removeAllRanges(); }
        else if (document.selection) { document.selection.empty(); }
    }
}